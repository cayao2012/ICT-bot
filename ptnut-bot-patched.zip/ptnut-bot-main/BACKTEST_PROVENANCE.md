# BACKTEST_PROVENANCE.md
## PTNUT Bot — Backtest Provenance Record

**Status:** Provenance frozen. Replay blocked pending `git lfs pull`.
**Date frozen:** 2026-03-26
**Frozen by:** Post-fix baseline validation pass (Patches 1–3 applied)

---

## Why This Document Exists

Two sets of headline numbers appear in the repo (`backtest_run.py` docstring and
`BACKTEST_RESULTS.md`) with different trade counts, different RR configs, and no
recorded run command. This document freezes what is determinable from the repo,
separates the two claims clearly, and defines the exact command needed to reproduce
the authoritative post-fix baseline once data is available.

---

## Data Files Required

Both baselines require the real data files, currently stored as Git LFS stubs:

| File | Path | LFS OID (sha256) | Size |
|---|---|---|---|
| NQ tick prices + timestamps | `data_new/NQ_ticks.npz` | `9010fc8ea01b5bcc5ad8e45b753a0b7d33de4bc44b72d353f5c8b5a9e97bcd67` | 1,961,187,543 bytes (~1.87 GB) |
| Bar cache (1m/5m/15m) | `data_new/bars_cache.pkl` | `e53c0550361df423df2777f42f5aab649bafd7da7c0844174b4ced3d3ebee6cc` | 154,743,514 bytes (~148 MB) |

**To pull:**
```bash
git lfs install
git lfs pull
# Verify:
python3 -c "import numpy as np; d=np.load('data_new/NQ_ticks.npz'); print(len(d['prices']), 'ticks')"
```

**After pulling, verify hashes:**
```bash
sha256sum data_new/NQ_ticks.npz data_new/bars_cache.pkl
```
Expected output should match the OIDs above.

---

## Baseline A — Authoritative Post-Fix Baseline (41-Day Window)

**This is the reproducible anchor.** It matches current `backtest_run.py` defaults
exactly. All three patches (Patches 1–3) are applied to the code before this run.

### Source
- `backtest_run.py` docstring + `BACKTEST_4YEAR_HANDOFF.md`

### Pre-fix claimed result (before Patches 1–3)
```
Trades:   182 (141W / 41L)
Win Rate: 77.5%
P&L:      $69,852
PF:       3.35
MaxDD:    $760
Window:   2026-01-19 → 2026-03-16 (41 trading days)
```

### Exact run command (post-fix)
```bash
cd /path/to/ptnut-bot
PYTHONPATH=tsxapi4py/src \
BACKTEST_START_DATE=2026-01-19 \
python3 -u backtest_run.py
```

### All config values (no env var overrides needed beyond START_DATE)

| Parameter | Value | Source |
|---|---|---|
| Runner | `backtest_run.py` | — |
| Signal engine | `gen_sweep_entries_enriched` + `apply_entry_mode` | `backtest_entry_modes.py` |
| Strategy | `v106_dynamic_rr_zone_entry.py` | imported |
| Contracts | 3 | `backtest_run.py:40` default |
| PV | $20/pt | `backtest_run.py:39` default |
| RR | Flat 1.1 (all zones) | `backtest_run.py:54` hardcoded |
| Zone filter | `disp_fvg` + `ifvg` | `backtest_run.py:55` hardcoded |
| Score filter | None (min=1, all scores) | `backtest_run.py:56` hardcoded |
| Slippage | 0.5 pt | `backtest_run.py:45` default |
| Fees (RT) | $8.40 | `backtest_run.py:41` default |
| MAX_RISK | $1,000/trade | `backtest_run.py:42` hardcoded |
| MCL | 3 per side | `backtest_run.py:44` hardcoded |
| GMCL | 2 | `backtest_run.py:47` default |
| DLL | -$2,000/day | `backtest_run.py:46` hardcoded |
| Cooldown | 120 seconds | `backtest_run.py:43` hardcoded |
| IFVG delay | ON (skip before 9:00 CT) | `backtest_run.py` default (`BACKTEST_IFVG_DELAY=1`) |
| KZ start | 7:30 CT | `backtest_run.py:47-50` defaults |
| KZ end | 14:30 CT | `backtest_run.py:47-50` defaults |
| Data dir | `data_new/` | `backtest_run.py:57` default |
| Bars file | `data_new/bars_cache.pkl` | `backtest_run.py:58` default |
| Start date | 2026-01-19 | `BACKTEST_START_DATE` env var |
| End date | end of data (~2026-03-16) | determined by data file |
| Tick outcome scope | 8 hours forward | `backtest_run.py:outcome_tick` |

### Patches applied before this run
- **Patch 1:** `ptnut_bot.py` — execution-size risk gate (does not affect `backtest_run.py`)
- **Patch 2:** `ptnut_bot.py` + `backtest_run.py` — trading-date session boundary fix
  - `backtest_run.build_dr` now reads `bar["date"]` from pickle (unchanged; bars_cache.pkl already uses trading date)
  - `ptnut_bot._build_dr` now uses `_bar_trading_date()` (affects live path only)
- **Patch 3:** `backtest_run.py` — `build_dr` end-index standardized to exclusive
  - `build_dr` now returns `(first_i, last_i + 1)` instead of `(first_i, last_i)`
  - Cursor loop changed from `range(ds5+1, de5+1)` to `range(ds5+1, de5)`
  - **Impact on Baseline A:** Patch 3 changes which bars are scanned by `get_liquidity_levels`. The last bar of each prior session is now included in PDH/PDL, Asia H/L, and swing level scans. This may produce small differences in liquidity levels vs the pre-fix run, most likely affecting sweeps detected near prior-session extremes.

### Expected post-fix changes vs pre-fix Baseline A
Patch 2 does not affect `backtest_run.py` (which already read trading dates from the
pickle). Patch 3 includes the last bar of each session in liquidity level scans.
Expected change: small number of liquidity levels may shift, which could change a
small number of sweep detections. Trade count and P&L expected to be close to 182
trades / 77.5% / $69,852 but not identical. Any difference is the measured impact of
Patch 3 on this 41-day window.

---

## Baseline B — 4-Year Headline Numbers (NOT reproducible with current code)

### Source
- `BACKTEST_RESULTS.md`

### Claimed result
```
Trades:     8,375 (6,074W / 2,296L)
Win Rate:   72.5%
P&L:        $2,379,494
PF:         2.46
MaxDD:      $4,865
Window:     2022-01-03 → 2026-03-16 (1,067 trading days)
```

### Why it is NOT reproducible with current code

| Difference | Claimed in BACKTEST_RESULTS.md | Current backtest_run.py |
|---|---|---|
| IFVG RR | 1.0 (separate from disp_fvg 1.1) | Flat 1.1 for all zones — no per-zone RR option |
| GMCL | 5 | 2 (default); overrideable to 5 via `BACKTEST_GMCL=5` |
| Code version | Unknown — prior to current repo state | Current post-patch state |

**The IFVG RR=1.0 setting is the critical gap.** `backtest_run.py` has `FLAT_RR = 1.1`
hardcoded and applies it to all zones. There is no `BACKTEST_IFVG_RR` env var.
Producing the 4-year numbers would require a code change to support per-zone RR —
which is a tuning decision, not a provenance fix.

**Closest approximation (still not identical):**
```bash
BACKTEST_GMCL=5 python3 -u backtest_run.py
```
This runs the full 4-year window at flat 1.1 RR and GMCL=5. Result will differ from
Baseline B due to IFVG RR being 1.1 instead of 1.0.

### Recommendation
Do not use Baseline B as a validation anchor until:
1. A `BACKTEST_IFVG_RR` env var is added to `backtest_run.py` (separate decision)
2. The exact code version that produced it is recovered or reconstructed
3. The result is re-run and verified against the claimed numbers

---

## What To Record After Running Baseline A

When the replay is run (once LFS data is available), fill in this table:

| Metric | Pre-fix claim | Post-fix actual | Delta |
|---|---|---|---|
| Total trades | 182 | ___ | ___ |
| Wins | 141 | ___ | ___ |
| Losses | 41 | ___ | ___ |
| Win rate | 77.5% | ___ | ___ |
| Total P&L | $69,852 | ___ | ___ |
| Avg win | ~$621 | ___ | ___ |
| Avg loss | ~$697 | ___ | ___ |
| Profit factor | 3.35 | ___ | ___ |
| Max drawdown | $760 | ___ | ___ |
| disp_fvg trades | ~112 | ___ | ___ |
| ifvg trades | ~70 | ___ | ___ |
| Losing days | 1 | ___ | ___ |

### Data file hashes to record at run time
```
sha256sum data_new/NQ_ticks.npz   → ___
sha256sum data_new/bars_cache.pkl → ___
```
These must match the OIDs listed above to confirm the correct dataset was used.

### Correctness checks during replay
After the run, verify:
- [ ] No `IndexError` or `KeyError` during bar scanning (would indicate Patch 3 cursor loop bug)
- [ ] Trade count is in the range 150–220 (large deviation suggests session boundary change)
- [ ] Date range in output matches 2026-01-19 → 2026-03-16
- [ ] No trades before 7:30 CT or after 14:30 CT (KZ enforcement)
- [ ] No ifvg trades before 9:00 CT (IFVG delay enforcement)
- [ ] Risk per trade never exceeds $1,000 (MAX_RISK enforcement, affected by Patch 3 via last-bar liquidity levels)

### Whether 41 days is enough to judge behavior
41 trading days is a small sample by most statistical standards.
At ~4.4 trades/day and 77.5% WR, the 95% confidence interval on win rate is approximately
±5–6 percentage points (Wilson interval on n=182). This means the true win rate could
plausibly be anywhere from ~71% to ~83% based on this sample alone. The sample is
sufficient to:
- Confirm the code runs without errors
- Confirm signal count is in the expected range
- Detect gross regressions (e.g., win rate dropping below 65% or above 90%)

It is NOT sufficient to:
- Claim statistical edge is proven
- Distinguish a 73% WR strategy from a 78% WR strategy with confidence
- Draw conclusions about profitability

The 4-year window (8,375 trades) would be sufficient for statistical inference.
That replay remains blocked until Baseline B becomes reproducible.

---

## Replay Environment Requirements

```bash
# Python version
python3 --version  # 3.9+ required for zoneinfo

# Required packages
pip install numpy pydantic pytz requests

# PYTHONPATH
export PYTHONPATH=/path/to/ptnut-bot/tsxapi4py/src

# Confirm data files are real (not LFS stubs)
python3 -c "
import numpy as np, pickle
ticks = np.load('data_new/NQ_ticks.npz')
print('ticks:', len(ticks['prices']), 'rows')
cache = pickle.load(open('data_new/bars_cache.pkl','rb'))
print('5m bars:', len(cache['b5']), '| 1m bars:', len(cache['b1']), '| 15m bars:', len(cache['b15']))
"
# Expected output (approximate):
#   ticks: ~100M+ rows
#   5m bars: ~300,000+ | 1m bars: ~1,500,000+ | 15m bars: ~100,000+
```

---

*This document must be updated with actual hash values and post-fix replay results
before any performance comparison is considered authoritative.*
