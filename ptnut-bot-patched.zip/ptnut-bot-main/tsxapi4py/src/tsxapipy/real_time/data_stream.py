# tsxapipy/real_time/data_stream.py
#
# Market data stream using pysignalr — follows TopstepX docs exactly.
# Token in URL, skipNegotiation, timeout 10s, auto reconnect, re-subscribe on reconnect.

import asyncio
import logging
import threading
import time
from typing import Dict, Any, Callable, Optional, List

from pysignalr.client import SignalRClient
from tsxapipy.config import MARKET_HUB_URL
from tsxapipy.api import APIClient
from .stream_state import StreamConnectionState

logger = logging.getLogger(__name__)

# Callback type aliases
QuoteCallback = Callable[[Dict[str, Any]], None]
TradeCallback = Callable[[Dict[str, Any]], None]
DepthCallback = Callable[[List[Dict[str, Any]]], None]
StreamErrorCallback = Callable[[Any], None]
StreamStateChangeCallback = Callable[[str], None]


class DataStream:
    """
    Handles real-time market data streaming from the TopStepX Market Hub
    using pysignalr (SignalR).

    Uses token in URL query param and skip_negotiation=True.
    Runs pysignalr's async event loop in a background daemon thread.
    Auto-reconnects and re-subscribes on reconnection.
    """

    def __init__(
        self,
        api_client: APIClient,
        contract_id_to_subscribe: str,
        on_quote_callback: Optional[QuoteCallback] = None,
        on_trade_callback: Optional[TradeCallback] = None,
        on_depth_callback: Optional[DepthCallback] = None,
        on_error_callback: Optional[StreamErrorCallback] = None,
        on_state_change_callback: Optional[StreamStateChangeCallback] = None,
        auto_subscribe_quotes: bool = False,
        auto_subscribe_trades: bool = False,
        auto_subscribe_depth: bool = True,
    ):
        self.logger = logging.getLogger(
            f"{__name__}.{self.__class__.__name__}[{contract_id_to_subscribe}]"
        )

        self.api_client = api_client
        self.contract_id_subscribed: str = contract_id_to_subscribe

        self._callbacks = {
            "quote": on_quote_callback,
            "trade": on_trade_callback,
            "depth": on_depth_callback,
        }

        self.on_error_callback = on_error_callback
        self.on_state_change_callback = on_state_change_callback

        self.auto_subscribe_quotes = auto_subscribe_quotes
        self.auto_subscribe_trades = auto_subscribe_trades
        self.auto_subscribe_depth = auto_subscribe_depth

        self._client: Optional[SignalRClient] = None
        # Keep `connection` attribute for any code that checks `self.connection`
        self.connection: Optional[SignalRClient] = None
        self.connection_status = StreamConnectionState.NOT_INITIALIZED

        self._current_token_for_url: Optional[str] = None
        self._wss_hub_url_no_token: str = ""
        self._hub_url_with_token: Optional[str] = None

        self._connection_lock = threading.RLock()
        self._is_manually_stopping = False

        # Background thread / asyncio loop
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._running = False

        self._prepare_websocket_url_base()
        try:
            self._refresh_auth_token_and_url()
        except Exception as e:
            self.logger.error(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                f"Failed to get initial token/URL during __init__: {e}",
                exc_info=True,
            )
            self._set_connection_state(
                StreamConnectionState.ERROR,
                f"Initial token/URL fail: {type(e).__name__}",
            )

        self.logger.info(
            f"DataStream initialized for contract: {self.contract_id_subscribed}"
        )

    # ------------------------------------------------------------------
    # URL / token helpers
    # ------------------------------------------------------------------

    def _prepare_websocket_url_base(self):
        if MARKET_HUB_URL.startswith("https://"):
            self._wss_hub_url_no_token = "wss://" + MARKET_HUB_URL[len("https://"):]
        elif MARKET_HUB_URL.startswith("http://"):
            self._wss_hub_url_no_token = "ws://" + MARKET_HUB_URL[len("http://"):]
        else:
            self.logger.warning(
                f"MARKET_HUB_URL '{MARKET_HUB_URL}' does not start with http(s). "
                "Using as is for wss base."
            )
            self._wss_hub_url_no_token = MARKET_HUB_URL
        self.logger.debug(
            f"DataStream (Contract: {self.contract_id_subscribed}): "
            f"Prepared base WebSocket URL: {self._wss_hub_url_no_token}"
        )

    def _refresh_auth_token_and_url(self):
        self.logger.debug(
            f"DataStream (Contract: {self.contract_id_subscribed}): "
            "Refreshing auth token and forming hub URL."
        )
        if not self.api_client:
            raise ConnectionError(
                "DataStream: APIClient not available for token refresh."
            )

        self._current_token_for_url = self.api_client.current_token
        if not self._current_token_for_url:
            raise ConnectionError(
                "DataStream: Failed to obtain a valid token from APIClient."
            )

        if not self._wss_hub_url_no_token:
            self._prepare_websocket_url_base()
            if not self._wss_hub_url_no_token:
                self.logger.error(
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    "Base WSS URL not set, cannot form full hub URL."
                )
                raise ConnectionError(
                    "DataStream: Base WSS Hub URL is not prepared."
                )

        self._hub_url_with_token = (
            f"{self._wss_hub_url_no_token}"
            f"?access_token={self._current_token_for_url}"
        )
        self.logger.debug(
            f"DataStream (Contract: {self.contract_id_subscribed}): "
            f"Auth token refreshed. Full Hub URL (token hidden): "
            f"{self._wss_hub_url_no_token}?access_token=TOKEN_HIDDEN"
        )

    # ------------------------------------------------------------------
    # pysignalr client builder
    # ------------------------------------------------------------------

    def _build_client(self):
        """Build a fresh SignalRClient with token in URL and skipNegotiation."""
        if not self._hub_url_with_token:
            try:
                self._refresh_auth_token_and_url()
            except ConnectionError as e:
                self.logger.error(
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    f"Failed to refresh token/URL during _build_client: {e}"
                )
                return
            if not self._hub_url_with_token:
                self.logger.error(
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    "_hub_url_with_token still missing after refresh attempt."
                )
                return

        self.logger.debug(
            f"DataStream (Contract: {self.contract_id_subscribed}): "
            "Building new pysignalr SignalRClient with token in URL and "
            "skip_negotiation=True."
        )

        client = SignalRClient(
            self._hub_url_with_token,
            connection_timeout=10,
            ping_interval=10,
            max_size=1_048_576,
        )
        # skipNegotiation — go straight to WebSocket, no HTTP negotiate
        client._transport._skip_negotiation = True

        cid = self.contract_id_subscribed

        # ---- lifecycle callbacks (all async for pysignalr) ----

        async def _on_open():
            self._set_connection_state(
                StreamConnectionState.CONNECTED, "SignalR connection opened"
            )
            await self._async_send_subscriptions(client)

        async def _on_close():
            if not self._is_manually_stopping:
                self.logger.warning(
                    f"DataStream (Contract: {cid}): SignalR connection closed "
                    f"unexpectedly. Current state: {self.connection_status.name}."
                )
                self._set_connection_state(
                    StreamConnectionState.DISCONNECTED,
                    "Connection closed (possibly after failed retries or "
                    "server disconnect)",
                )
            else:
                self._set_connection_state(
                    StreamConnectionState.DISCONNECTED,
                    "Connection stopped by client",
                )

        async def _on_error(err):
            error_msg = str(err) if err else "Unknown SignalR error"
            self.logger.error(
                f"DataStream ({cid}): SignalR error: {error_msg}",
                exc_info=isinstance(err, Exception),
            )
            self._set_connection_state(
                StreamConnectionState.ERROR, error_msg[:150]
            )
            if self.on_error_callback:
                try:
                    self.on_error_callback(err)
                except Exception as e_cb:
                    self.logger.error(
                        f"DataStream ({cid}): Error in user's on_error_callback: "
                        f"{e_cb}",
                        exc_info=True,
                    )

        # ---- data callbacks ----

        async def _handle_quote(args):
            self.logger.debug(
                f"DataStream ({cid}): _handle_quote raw args: {args}"
            )
            if not isinstance(args, list) or len(args) < 2:
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayQuote unexpected "
                    f"message_args format: {args}"
                )
                return
            contract_id_from_event = args[0]
            quote_payload = args[1]
            if not isinstance(quote_payload, dict) or not isinstance(
                contract_id_from_event, str
            ):
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayQuote - Invalid types."
                )
                return
            if contract_id_from_event == cid and self._callbacks["quote"]:
                try:
                    self.logger.debug(
                        f"DataStream ({cid}): Invoking on_quote_callback"
                    )
                    self._callbacks["quote"](quote_payload)
                except Exception as e:
                    self.logger.error(
                        f"DataStream (Contract: {cid}): Error in "
                        f"on_quote_callback: {e}",
                        exc_info=True,
                    )
            elif contract_id_from_event != cid:
                self.logger.warning(
                    f"DataStream: Received quote for mismatched contract_id: "
                    f"{contract_id_from_event} (expected {cid})"
                )

        async def _handle_trade(args):
            self.logger.debug(
                f"DataStream ({cid}): _handle_trade raw args: {args}"
            )
            if not isinstance(args, list) or len(args) < 2:
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayTrade unexpected "
                    f"message_args format: {args}"
                )
                return
            contract_id_from_event = args[0]
            trade_data_payload = args[1]
            if not isinstance(contract_id_from_event, str):
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayTrade - Invalid "
                    f"type for ContractID: {type(contract_id_from_event)}"
                )
                return
            if not self._callbacks["trade"]:
                return

            if isinstance(trade_data_payload, list):
                for single_trade_dict in trade_data_payload:
                    if not isinstance(single_trade_dict, dict):
                        self.logger.warning(
                            f"DataStream (Contract: {cid}): GatewayTrade - "
                            f"Item in trade list is not a dict: "
                            f"{type(single_trade_dict)}"
                        )
                        continue
                    self.logger.info(
                        f"DataStream ({cid}): PROCESSING TRADE (from list): "
                        f"{single_trade_dict}"
                    )
                    try:
                        self._callbacks["trade"](single_trade_dict)
                    except Exception as e:
                        self.logger.error(
                            f"DataStream (Contract: {cid}): Error in "
                            f"on_trade_callback: {e}",
                            exc_info=True,
                        )
            elif isinstance(trade_data_payload, dict):
                self.logger.info(
                    f"DataStream ({cid}): PROCESSING TRADE (direct dict): "
                    f"{trade_data_payload}"
                )
                try:
                    self._callbacks["trade"](trade_data_payload)
                except Exception as e:
                    self.logger.error(
                        f"DataStream (Contract: {cid}): Error in "
                        f"on_trade_callback: {e}",
                        exc_info=True,
                    )
            else:
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayTrade - Expected "
                    f"payload to be list or dict, got: "
                    f"{type(trade_data_payload)}"
                )

        async def _handle_depth(args):
            self.logger.debug(
                f"DataStream ({cid}): _handle_depth raw args: {args}"
            )
            if not isinstance(args, list) or len(args) < 2:
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayDepth unexpected "
                    f"message_args format: {args}"
                )
                return
            contract_id_from_event = args[0]
            depth_payload_list = args[1]
            if not isinstance(depth_payload_list, list) or not isinstance(
                contract_id_from_event, str
            ):
                self.logger.warning(
                    f"DataStream (Contract: {cid}): GatewayDepth - Invalid types."
                )
                return
            if contract_id_from_event == cid and self._callbacks["depth"]:
                try:
                    self.logger.debug(
                        f"DataStream ({cid}): Invoking on_depth_callback "
                        f"with list of length {len(depth_payload_list)}."
                    )
                    self._callbacks["depth"](depth_payload_list)
                except Exception as e:
                    self.logger.error(
                        f"DataStream (Contract: {cid}): Error in "
                        f"on_depth_callback: {e}",
                        exc_info=True,
                    )
            elif contract_id_from_event != cid:
                self.logger.warning(
                    f"DataStream: Received depth for mismatched contract_id: "
                    f"{contract_id_from_event} (expected {cid})"
                )

        # ---- register handlers on the client ----

        client.on_open(_on_open)
        client.on_close(_on_close)
        client.on_error(_on_error)

        if self._callbacks["quote"]:
            client.on("GatewayQuote", _handle_quote)
        if self._callbacks["trade"]:
            client.on("GatewayTrade", _handle_trade)
        if self._callbacks["depth"]:
            client.on("GatewayDepth", _handle_depth)

        self._client = client
        self.connection = client  # alias for external code checking self.connection
        self.logger.debug(
            f"DataStream (Contract: {cid}): pysignalr client built and "
            "event handlers registered."
        )

    # ------------------------------------------------------------------
    # Subscription helpers
    # ------------------------------------------------------------------

    async def _async_send_subscriptions(self, client: SignalRClient):
        """Send all enabled subscriptions. Called from on_open (async context)."""
        cid = self.contract_id_subscribed
        self.logger.info(
            f"DataStream ({cid}): Sending subscriptions..."
        )

        try:
            if self.auto_subscribe_quotes and self._callbacks["quote"]:
                self.logger.info(
                    f"DataStream ({cid}): Sending SubscribeContractQuotes"
                )
                await client.send("SubscribeContractQuotes", [cid])
                self.logger.info(
                    f"DataStream ({cid}): SubscribeContractQuotes SENT"
                )
            elif self.auto_subscribe_quotes and not self._callbacks["quote"]:
                self.logger.warning(
                    f"DataStream ({cid}): auto_subscribe_quotes is True, "
                    "but no quote callback registered. Skipping."
                )

            if self.auto_subscribe_trades and self._callbacks["trade"]:
                self.logger.info(
                    f"DataStream ({cid}): Sending SubscribeContractTrades"
                )
                await client.send("SubscribeContractTrades", [cid])
                self.logger.info(
                    f"DataStream ({cid}): SubscribeContractTrades SENT"
                )
            elif self.auto_subscribe_trades and not self._callbacks["trade"]:
                self.logger.warning(
                    f"DataStream ({cid}): auto_subscribe_trades is True, "
                    "but no trade callback registered. Skipping."
                )

            if self.auto_subscribe_depth and self._callbacks["depth"]:
                self.logger.info(
                    f"DataStream ({cid}): Sending SubscribeContractMarketDepth"
                )
                await client.send("SubscribeContractMarketDepth", [cid])
                self.logger.info(
                    f"DataStream ({cid}): SubscribeContractMarketDepth SENT"
                )
            elif self.auto_subscribe_depth and not self._callbacks["depth"]:
                self.logger.warning(
                    f"DataStream ({cid}): auto_subscribe_depth is True, "
                    "but no depth callback registered. Skipping."
                )

            self.logger.info(
                f"DataStream ({cid}): All enabled subscriptions dispatched."
            )

        except Exception as e:
            self.logger.error(
                f"DataStream ({cid}): Exception during subscription sends: {e}",
                exc_info=True,
            )
            self._set_connection_state(
                StreamConnectionState.ERROR,
                f"Subscription send exception: {type(e).__name__}",
            )

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def _set_connection_state(
        self,
        new_state: StreamConnectionState,
        reason: Optional[str] = None,
    ):
        with self._connection_lock:
            if self.connection_status != new_state:
                old_state_name = self.connection_status.name
                self.connection_status = new_state
                log_msg = (
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    f"State changed from {old_state_name} to {new_state.name}."
                )
                if reason:
                    log_msg += f" Reason: {reason}"
                self.logger.info(log_msg)
                if self.on_state_change_callback:
                    try:
                        self.on_state_change_callback(new_state.name)
                    except Exception as e_cb:
                        self.logger.error(
                            f"DataStream (Contract: "
                            f"{self.contract_id_subscribed}): "
                            f"Error in on_state_change_callback: {e_cb}",
                            exc_info=True,
                        )

    # ------------------------------------------------------------------
    # Background thread running pysignalr async loop
    # ------------------------------------------------------------------

    def _run_loop(self):
        """Run pysignalr in its own asyncio loop. Auto-restart on failure."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        while self._running:
            # Refresh token & rebuild client each iteration so reconnects
            # pick up the latest token.
            try:
                self._refresh_auth_token_and_url()
            except Exception as e:
                self.logger.error(
                    f"DataStream ({self.contract_id_subscribed}): "
                    f"Token refresh failed in run loop: {e}"
                )
                if self._running:
                    time.sleep(5)
                continue

            self._build_client()
            if not self._client:
                self.logger.error(
                    f"DataStream ({self.contract_id_subscribed}): "
                    "_build_client produced no client. Retrying in 5s..."
                )
                if self._running:
                    time.sleep(5)
                continue

            try:
                self._set_connection_state(
                    StreamConnectionState.CONNECTING,
                    "pysignalr client.run() starting",
                )
                self._loop.run_until_complete(self._client.run())
            except Exception as e:
                self.logger.error(
                    f"DataStream ({self.contract_id_subscribed}): "
                    f"pysignalr run() error: {e}",
                    exc_info=True,
                )

            # If we get here, run() exited — reconnect unless manually stopped
            if self._running and not self._is_manually_stopping:
                self.logger.warning(
                    f"DataStream ({self.contract_id_subscribed}): "
                    "pysignalr run() exited — auto-reconnecting in 5s..."
                )
                self._set_connection_state(
                    StreamConnectionState.RECONNECTING_UNEXPECTED,
                    "pysignalr run() exited, will retry",
                )
                time.sleep(5)

        # Clean up the loop when we're done
        try:
            self._loop.close()
        except Exception:
            pass
        self._loop = None

    # ------------------------------------------------------------------
    # Public API: start / stop / update_token
    # ------------------------------------------------------------------

    def start(self) -> bool:
        with self._connection_lock:
            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                f"Start called. Current state: {self.connection_status.name}"
            )
            self._is_manually_stopping = False

            if self._running:
                self.logger.warning(
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    "Already running."
                )
                return True

            # Make sure we have a token
            if not self._hub_url_with_token:
                try:
                    self._refresh_auth_token_and_url()
                except Exception as e_prep:
                    self.logger.error(
                        f"DataStream (Contract: {self.contract_id_subscribed}): "
                        f"Prep failed in start(): {e_prep}",
                        exc_info=True,
                    )
                    self._set_connection_state(
                        StreamConnectionState.ERROR,
                        f"Prep failed in start: {type(e_prep).__name__}",
                    )
                    return False

            self._running = True
            self._thread = threading.Thread(
                target=self._run_loop, daemon=True, name=f"DataStream-{self.contract_id_subscribed}"
            )
            self._thread.start()
            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                "Background thread started. Waiting for connection..."
            )
            return True

    def stop(self, reason_for_stop: Optional[str] = "User requested stop"):
        with self._connection_lock:
            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                f"Stop called. Reason: '{reason_for_stop}'. "
                f"Current state: {self.connection_status.name}"
            )
            self._is_manually_stopping = True
            self._set_connection_state(
                StreamConnectionState.STOPPING, reason_for_stop
            )

            self._running = False

            # Stop the asyncio event loop if it's running
            loop = self._loop
            thread = self._thread

        # Release the lock before joining the thread to avoid deadlock.
        # The background thread may be inside _set_connection_state which
        # also acquires _connection_lock.
        if loop and loop.is_running():
            loop.call_soon_threadsafe(loop.stop)

        if thread and thread.is_alive():
            thread.join(timeout=5)
            if thread.is_alive():
                self.logger.warning(
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    "Background thread did not exit within 5s timeout."
                )

        with self._connection_lock:
            self._client = None
            self.connection = None

            # Set final state if not already DISCONNECTED
            if self.connection_status != StreamConnectionState.DISCONNECTED:
                self._set_connection_state(
                    StreamConnectionState.DISCONNECTED,
                    "Connection stopped by client",
                )

    def update_token(self, new_token: str):
        if not new_token:
            self.logger.error(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                "Attempted to update token with an empty new token. "
                "Ignoring."
            )
            return

        with self._connection_lock:
            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                "Token update requested."
            )

            # If token hasn't changed and stream is healthy, skip
            if (
                new_token == self._current_token_for_url
                and self.connection_status == StreamConnectionState.CONNECTED
            ):
                self.logger.debug(
                    f"DataStream (Contract: {self.contract_id_subscribed}): "
                    "New token string is same as current, and stream "
                    "connected. No restart needed."
                )
                return

            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                "Proceeding with connection restart for token update."
            )

            # Update the stored token so the next _build_client picks it up
            self._current_token_for_url = new_token
            self._hub_url_with_token = (
                f"{self._wss_hub_url_no_token}"
                f"?access_token={self._current_token_for_url}"
            )

            was_running = self._running

        # Stop and restart outside the lock to avoid deadlock with the
        # background thread (stop() joins the thread which may be waiting
        # on _connection_lock inside _set_connection_state).
        if was_running:
            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                "Stopping existing connection for token update."
            )
            self.stop(reason_for_stop="Token update initiated stop")

        # Restart if we were running before
        if was_running:
            self.logger.info(
                f"DataStream (Contract: {self.contract_id_subscribed}): "
                "Restarting connection with new token."
            )
            self._is_manually_stopping = False
            if not self.start():
                self.logger.error(
                    f"DataStream (Contract: "
                    f"{self.contract_id_subscribed}): "
                    "Failed to restart stream after token update."
                )
