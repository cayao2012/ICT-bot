# tsxapipy/real_time/user_hub_stream.py
"""User Hub stream using pysignalr -- follows TopstepX docs exactly.

Token in URL query param, skipNegotiation=True, WebSocket transport,
auto-reconnect with re-subscribe on reconnect.

Events handled:
  - GatewayUserAccount  -> on_account_update callback
  - GatewayUserOrder    -> on_order_update callback
  - GatewayUserPosition -> on_position_update callback
  - GatewayUserTrade    -> on_user_trade_update callback
"""
import asyncio
import logging
import threading
import time
from typing import Callable, Optional, Any, List, Dict

from pysignalr.client import SignalRClient

from tsxapipy.config import USER_HUB_URL
from tsxapipy.api import APIClient
from .stream_state import StreamConnectionState

logger = logging.getLogger(__name__)

# Callback type aliases
AccountUpdateCallback = Callable[[Dict[str, Any]], None]
OrderUpdateCallback = Callable[[Dict[str, Any]], None]
PositionUpdateCallback = Callable[[Dict[str, Any]], None]
UserTradeCallback = Callable[[Dict[str, Any]], None]
StreamErrorCallback = Callable[[Any], None]
StreamStateChangeCallback = Callable[[str], None]  # Argument is state name (str)


def _extract_payload(args: Any, event_name: str) -> Optional[Dict[str, Any]]:
    """Extract the dict payload from SignalR event args.

    User hub events arrive in various shapes depending on pysignalr version
    and server behaviour:
      - [dict]             -- single payload wrapped in a list
      - dict               -- raw payload
      - [accountId, dict]  -- two-element list with account ID prefix
      - [[dict]]           -- nested list
    """
    if isinstance(args, dict):
        return args
    if isinstance(args, list):
        if len(args) == 1 and isinstance(args[0], dict):
            return args[0]
        if len(args) >= 2 and isinstance(args[-1], dict):
            return args[-1]
        if len(args) == 1 and isinstance(args[0], list) and args[0]:
            inner = args[0]
            if isinstance(inner[0], dict):
                return inner[0]
    logger.warning(
        f"UserHubStream: {event_name}: unexpected payload structure: "
        f"{type(args)} -- {str(args)[:200]}"
    )
    return None


class UserHubStream:
    """
    Manages a SignalR connection to the TopStep User Hub for real-time
    user-specific data using pysignalr.

    Runs pysignalr's async event loop in a background daemon thread so the
    rest of the bot can remain fully synchronous.
    """

    def __init__(
        self,
        api_client: APIClient,
        account_id_to_watch: int,
        on_order_update: Optional[OrderUpdateCallback] = None,
        on_position_update: Optional[PositionUpdateCallback] = None,
        on_account_update: Optional[AccountUpdateCallback] = None,
        on_user_trade_update: Optional[UserTradeCallback] = None,
        subscribe_to_accounts_globally: bool = True,
        on_error_callback: Optional[StreamErrorCallback] = None,
        on_state_change_callback: Optional[StreamStateChangeCallback] = None,
    ):
        """
        Initialize the UserHubStream.

        Args:
            api_client: APIClient instance used to obtain/refresh auth tokens.
            account_id_to_watch: Numeric account ID for per-account subscriptions.
            on_order_update: Called with a dict for every GatewayUserOrder event.
            on_position_update: Called with a dict for every GatewayUserPosition event.
            on_account_update: Called with a dict for every GatewayUserAccount event.
            on_user_trade_update: Called with a dict for every GatewayUserTrade event.
            subscribe_to_accounts_globally: If True, SubscribeAccounts is sent without
                an account ID (subscribes to all accounts).
            on_error_callback: Called on SignalR transport errors.
            on_state_change_callback: Called with the new state name string whenever
                the connection state changes.
        """
        self.logger = logger
        self.api_client = api_client
        self.account_id = account_id_to_watch

        self._callbacks: Dict[str, Optional[Callable]] = {
            "order": on_order_update,
            "position": on_position_update,
            "account": on_account_update,
            "user_trade": on_user_trade_update,
        }
        self.subscribe_to_accounts_globally = subscribe_to_accounts_globally
        self.on_error_callback = on_error_callback
        self.on_state_change_callback = on_state_change_callback

        self.connection_status = StreamConnectionState.NOT_INITIALIZED

        # Token / URL bookkeeping
        self._current_token_for_url: Optional[str] = None
        self._wss_hub_url_no_token: str = ""
        self._hub_url_with_token: Optional[str] = None

        # pysignalr internals
        self._client: Optional[SignalRClient] = None
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._running: bool = False
        self._stop_event = threading.Event()

        # Prepare URL and get initial token
        self._prepare_websocket_url_base()
        try:
            self._reinitialize_token_and_url()
        except Exception as e:
            self.logger.error(
                f"UserHubStream __init__: Failed to get initial token: {e}"
            )
            self._set_connection_state(
                StreamConnectionState.ERROR,
                f"Initial token fail: {type(e).__name__}",
            )

        self.logger.info(
            f"UserHubStream initialized for Account ID: {self.account_id}. "
            f"Global Sub: {self.subscribe_to_accounts_globally}"
        )

    # ------------------------------------------------------------------
    # URL / token helpers
    # ------------------------------------------------------------------

    def _prepare_websocket_url_base(self):
        """Convert the config USER_HUB_URL (https://...) to a wss:// base URL."""
        if USER_HUB_URL.startswith("https://"):
            self._wss_hub_url_no_token = "wss://" + USER_HUB_URL[len("https://"):]
        elif USER_HUB_URL.startswith("http://"):
            self._wss_hub_url_no_token = "ws://" + USER_HUB_URL[len("http://"):]
        else:
            self.logger.warning(
                f"USER_HUB_URL '{USER_HUB_URL}' does not start with http(s). "
                "Using as-is for wss base."
            )
            self._wss_hub_url_no_token = USER_HUB_URL
        self.logger.debug(
            f"UserHubStream: Prepared base WebSocket URL: {self._wss_hub_url_no_token}"
        )

    def _reinitialize_token_and_url(self):
        """Fetch a fresh token from APIClient and update the full connection URL."""
        self.logger.debug(
            f"UserHubStream (Acct: {self.account_id}): "
            "Re-initializing token and Hub URL."
        )
        if not self.api_client:
            raise ConnectionError(
                "UserHubStream: APIClient not available for token refresh."
            )

        self._current_token_for_url = self.api_client.current_token
        if not self._current_token_for_url:
            raise ConnectionError(
                "UserHubStream: Failed to obtain a valid token from APIClient."
            )

        if not self._wss_hub_url_no_token:
            self.logger.error(
                "UserHubStream: _wss_hub_url_no_token is not set. "
                "Cannot form full hub URL."
            )
            raise ConnectionError(
                "UserHubStream: Base WSS Hub URL is not prepared."
            )

        self._hub_url_with_token = (
            f"{self._wss_hub_url_no_token}"
            f"?access_token={self._current_token_for_url}"
        )
        self.logger.debug(
            f"UserHubStream (Acct: {self.account_id}): Hub URL updated with new token."
        )

    # ------------------------------------------------------------------
    # Connection state management
    # ------------------------------------------------------------------

    def _set_connection_state(
        self, new_state: StreamConnectionState, reason: Optional[str] = None
    ):
        """Update connection state, log the transition, invoke callback."""
        if self.connection_status != new_state:
            old_state_name = self.connection_status.name
            self.connection_status = new_state
            log_msg = (
                f"UserHubStream (Acct: {self.account_id}): "
                f"State changed from {old_state_name} to {new_state.name}."
            )
            if reason:
                log_msg += f" Reason: {reason}"
            self.logger.info(log_msg)
            if self.on_state_change_callback:
                try:
                    self.on_state_change_callback(new_state.name)
                except Exception as e_cb:
                    self.logger.error(
                        f"UserHubStream (Acct: {self.account_id}): "
                        f"Error in on_state_change_callback: {e_cb}",
                        exc_info=True,
                    )

    # ------------------------------------------------------------------
    # pysignalr client builder
    # ------------------------------------------------------------------

    def _build_client(self):
        """Create a fresh SignalRClient with current token and register all handlers."""
        if not self._hub_url_with_token:
            self.logger.error(
                "UserHubStream: Cannot build client, _hub_url_with_token is not set."
            )
            return

        self.logger.debug(
            f"UserHubStream (Acct: {self.account_id}): Building new pysignalr client "
            f"for URL (token hidden): {self._wss_hub_url_no_token}?token=..."
        )

        self._client = SignalRClient(
            self._hub_url_with_token,
            connection_timeout=10,
            ping_interval=10,
            max_size=1_048_576,
        )
        # Skip negotiation -- direct WebSocket, per TopstepX docs
        self._client._transport._skip_negotiation = True

        # Capture references for closures
        client = self._client
        account_id = self.account_id

        # -- on_open: set state CONNECTED, then send all subscriptions --
        async def _on_open():
            self.logger.info(
                f"UserHubStream (Acct: {account_id}): "
                "CONNECTED -- sending subscriptions."
            )
            self._set_connection_state(
                StreamConnectionState.CONNECTED, "pysignalr connection opened"
            )
            await self._async_send_subscriptions(client)

        # -- on_close --
        async def _on_close():
            self.logger.warning(
                f"UserHubStream (Acct: {account_id}): Disconnected."
            )
            if self.connection_status not in (
                StreamConnectionState.STOPPING,
                StreamConnectionState.DISCONNECTED,
                StreamConnectionState.ERROR,
            ):
                self._set_connection_state(
                    StreamConnectionState.DISCONNECTED,
                    "pysignalr connection closed -- auto-reconnect will handle",
                )

        # -- on_error --
        async def _on_error(err):
            error_message = str(err) if err else "Unknown pysignalr error"
            self.logger.error(
                f"UserHubStream (Acct: {account_id}): "
                f"Transport error: {error_message}",
                exc_info=isinstance(err, Exception),
            )
            self._set_connection_state(
                StreamConnectionState.ERROR,
                f"pysignalr transport error: {error_message[:100]}",
            )
            if self.on_error_callback:
                try:
                    self.on_error_callback(err)
                except Exception as e_cb:
                    self.logger.error(
                        f"UserHubStream (Acct: {account_id}): "
                        f"Error in on_error_callback: {e_cb}",
                        exc_info=True,
                    )

        # -- Hub event handlers (async wrappers that call sync user callbacks) --
        async def _handle_order(args):
            payload = _extract_payload(args, "GatewayUserOrder")
            if payload and self._callbacks["order"]:
                try:
                    self._callbacks["order"](payload)
                except Exception as e:
                    self.logger.error(
                        f"UserHubStream (Acct: {account_id}): "
                        f"Error in on_order_update callback: {e}",
                        exc_info=True,
                    )

        async def _handle_position(args):
            payload = _extract_payload(args, "GatewayUserPosition")
            if payload and self._callbacks["position"]:
                try:
                    self._callbacks["position"](payload)
                except Exception as e:
                    self.logger.error(
                        f"UserHubStream (Acct: {account_id}): "
                        f"Error in on_position_update callback: {e}",
                        exc_info=True,
                    )

        async def _handle_account(args):
            payload = _extract_payload(args, "GatewayUserAccount")
            if payload and self._callbacks["account"]:
                try:
                    self._callbacks["account"](payload)
                except Exception as e:
                    self.logger.error(
                        f"UserHubStream (Acct: {account_id}): "
                        f"Error in on_account_update callback: {e}",
                        exc_info=True,
                    )

        async def _handle_user_trade(args):
            payload = _extract_payload(args, "GatewayUserTrade")
            if payload and self._callbacks["user_trade"]:
                try:
                    self._callbacks["user_trade"](payload)
                except Exception as e:
                    self.logger.error(
                        f"UserHubStream (Acct: {account_id}): "
                        f"Error in on_user_trade_update callback: {e}",
                        exc_info=True,
                    )

        # Register lifecycle handlers
        client.on_open(_on_open)
        client.on_close(_on_close)
        client.on_error(_on_error)

        # Register hub event handlers (only for callbacks that are set)
        if self._callbacks["order"]:
            client.on("GatewayUserOrder", _handle_order)
        if self._callbacks["position"]:
            client.on("GatewayUserPosition", _handle_position)
        if self._callbacks["account"]:
            client.on("GatewayUserAccount", _handle_account)
        if self._callbacks["user_trade"]:
            client.on("GatewayUserTrade", _handle_user_trade)

        self.logger.debug(
            f"UserHubStream (Acct: {self.account_id}): "
            "pysignalr event handlers registered."
        )

    # ------------------------------------------------------------------
    # Subscription logic (async -- called from on_open inside the loop)
    # ------------------------------------------------------------------

    async def _async_send_subscriptions(self, client: SignalRClient):
        """Send all configured subscriptions to the User Hub.

        Called from the async on_open handler. When pysignalr's run() loop
        reconnects (rebuilds client), on_open fires again and this re-sends
        all subscriptions automatically.
        """
        try:
            self.logger.info(
                f"UserHubStream (Acct: {self.account_id}): Sending subscriptions. "
                f"Global: {self.subscribe_to_accounts_globally}"
            )

            # SubscribeAccounts
            if self._callbacks["account"]:
                if self.subscribe_to_accounts_globally:
                    self.logger.info(
                        f"UserHubStream (Acct: {self.account_id}): "
                        "Subscribing to all accounts globally (SubscribeAccounts)."
                    )
                    await client.send("SubscribeAccounts", [])
                elif self.account_id > 0:
                    self.logger.info(
                        f"UserHubStream (Acct: {self.account_id}): "
                        "Subscribing to specific account (SubscribeAccounts)."
                    )
                    await client.send("SubscribeAccounts", [self.account_id])
                else:
                    self.logger.warning(
                        f"UserHubStream (Acct: {self.account_id}): "
                        "Account callback set but global sub is false and "
                        "account ID is invalid. No account subscription sent."
                    )

            # Per-account subscriptions: SubscribeOrders, SubscribePositions, SubscribeTrades
            if self.account_id > 0:
                if self._callbacks["order"]:
                    self.logger.info(
                        f"UserHubStream (Acct: {self.account_id}): "
                        "Subscribing to orders (SubscribeOrders)."
                    )
                    await client.send("SubscribeOrders", [self.account_id])
                if self._callbacks["position"]:
                    self.logger.info(
                        f"UserHubStream (Acct: {self.account_id}): "
                        "Subscribing to positions (SubscribePositions)."
                    )
                    await client.send("SubscribePositions", [self.account_id])
                if self._callbacks["user_trade"]:
                    self.logger.info(
                        f"UserHubStream (Acct: {self.account_id}): "
                        "Subscribing to user trades (SubscribeTrades)."
                    )
                    await client.send("SubscribeTrades", [self.account_id])
            elif (
                self._callbacks["order"]
                or self._callbacks["position"]
                or self._callbacks["user_trade"]
            ):
                self.logger.warning(
                    f"UserHubStream (Acct: {self.account_id}): "
                    "Callbacks for Orders/Positions/UserTrades exist, but "
                    "account_id is invalid. Not subscribing."
                )

            self.logger.info(
                f"UserHubStream (Acct: {self.account_id}): "
                "Subscription messages sent."
            )
        except Exception as e:
            self.logger.error(
                f"UserHubStream (Acct: {self.account_id}): "
                f"Error sending subscriptions: {e}",
                exc_info=True,
            )
            self._set_connection_state(
                StreamConnectionState.ERROR,
                f"Subscription send error: {type(e).__name__}",
            )

    # ------------------------------------------------------------------
    # Background thread running the async event loop
    # ------------------------------------------------------------------

    def _run_loop(self):
        """Run pysignalr in its own asyncio event loop.

        If the client's run() exits (disconnect, error), rebuild the client
        with a fresh token and reconnect -- unless stop() was called.
        This provides robust auto-reconnect with token refresh.
        """
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        while self._running:
            # Refresh token before each (re)connect attempt
            try:
                self._reinitialize_token_and_url()
            except Exception as e:
                self.logger.error(
                    f"UserHubStream (Acct: {self.account_id}): "
                    f"Token refresh failed before connect: {e}"
                )
                self._set_connection_state(
                    StreamConnectionState.ERROR,
                    f"Token refresh failed: {type(e).__name__}",
                )
                if self._running:
                    time.sleep(5)
                continue

            self._build_client()

            if not self._client:
                self.logger.error(
                    f"UserHubStream (Acct: {self.account_id}): "
                    "Client build failed, retrying in 5s..."
                )
                if self._running:
                    time.sleep(5)
                continue

            self._set_connection_state(
                StreamConnectionState.CONNECTING,
                "pysignalr client.run() starting",
            )

            try:
                self._loop.run_until_complete(self._client.run())
            except Exception as e:
                self.logger.error(
                    f"UserHubStream (Acct: {self.account_id}): "
                    f"pysignalr run() error: {e}",
                    exc_info=True,
                )

            # If we get here, pysignalr's run() has exited
            if self._running:
                self.logger.warning(
                    f"UserHubStream (Acct: {self.account_id}): "
                    "run() exited -- reconnecting in 5s with fresh token..."
                )
                self._set_connection_state(
                    StreamConnectionState.RECONNECTING_UNEXPECTED,
                    "run() exited, will reconnect",
                )
                time.sleep(5)

        # Clean exit
        if self._loop and not self._loop.is_closed():
            self._loop.close()
        self._loop = None

    # ------------------------------------------------------------------
    # Public API: start / stop / update_token
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """Start the SignalR connection to the User Hub.

        Launches a background daemon thread that runs pysignalr's async loop.
        Returns True if the start was initiated, False on failure.
        """
        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): Start called. "
            f"Current state: {self.connection_status.name}"
        )

        if self._running:
            self.logger.warning(
                f"UserHubStream (Acct: {self.account_id}): "
                "Start called but stream is already running."
            )
            return True

        # Make sure we have a valid URL
        if not self._hub_url_with_token:
            try:
                if not self._wss_hub_url_no_token:
                    self._prepare_websocket_url_base()
                self._reinitialize_token_and_url()
            except Exception as e:
                self.logger.error(
                    f"UserHubStream (Acct: {self.account_id}): "
                    f"Failed to prepare URL during start(): {e}",
                    exc_info=True,
                )
                self._set_connection_state(
                    StreamConnectionState.ERROR,
                    f"Prep failed in start: {type(e).__name__}",
                )
                return False

        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name=f"UserHubStream-{self.account_id}",
        )
        self._thread.start()
        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): Background thread started."
        )
        return True

    def stop(self, reason_for_stop: Optional[str] = "User requested stop"):
        """Stop the SignalR connection.

        Signals the background thread to exit, stops the async event loop,
        and waits for the thread to join.
        """
        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): Stop called. "
            f"Reason: '{reason_for_stop}'. "
            f"Current state: {self.connection_status.name}"
        )

        self._set_connection_state(StreamConnectionState.STOPPING, reason_for_stop)
        self._running = False
        self._stop_event.set()

        # Tell the asyncio loop to stop so run_until_complete() returns
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)

        # Wait for the background thread to exit
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=10)
            if self._thread.is_alive():
                self.logger.warning(
                    f"UserHubStream (Acct: {self.account_id}): "
                    "Background thread did not exit within 10s."
                )

        self._thread = None
        self._client = None

        self._set_connection_state(
            StreamConnectionState.DISCONNECTED,
            reason_for_stop or "Stopped",
        )
        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): Stopped."
        )

    def update_token(self, new_token: str):
        """Update the authentication token and restart the connection.

        Stops the current connection, updates the token, rebuilds the URL,
        and starts a fresh connection with the new token.
        """
        if not new_token:
            self.logger.error(
                f"UserHubStream (Acct: {self.account_id}): "
                "Attempted to update token with an empty new token. Ignoring."
            )
            return

        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): Token update requested. "
            f"Old token prefix: "
            f"{self._current_token_for_url[:10] if self._current_token_for_url else 'None'}, "
            f"New token prefix: {new_token[:10]}..."
        )

        if (
            new_token == self._current_token_for_url
            and self.connection_status == StreamConnectionState.CONNECTED
        ):
            self.logger.debug(
                f"UserHubStream (Acct: {self.account_id}): "
                "Token unchanged and already connected. No action taken."
            )
            return

        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): "
            "Proceeding with connection restart for token update."
        )

        # Stop current connection if active
        if self._running:
            self.stop(reason_for_stop="Token update initiated stop")

        # Update token and URL
        self._current_token_for_url = new_token
        if not self._wss_hub_url_no_token:
            self._prepare_websocket_url_base()
        self._hub_url_with_token = (
            f"{self._wss_hub_url_no_token}"
            f"?access_token={self._current_token_for_url}"
        )

        self.logger.info(
            f"UserHubStream (Acct: {self.account_id}): "
            "Starting connection with new token."
        )
        self.start()
